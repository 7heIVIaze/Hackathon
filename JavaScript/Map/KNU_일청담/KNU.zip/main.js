App.onJoinPlayer.Add(function(player) {
    App.showCenterLabel(`경북대학교 일청담`);
})