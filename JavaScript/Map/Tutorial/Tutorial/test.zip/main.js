App.onJoinPlayer.Add(function(player) {
    App.showCenterLabel("대구 관광지 투어에 오신 여러분들 환영합니다.");
})