App.onJoinPlayer.Add(function(player) {
    App.showCenterLabel(`케이블카 내부`);
})