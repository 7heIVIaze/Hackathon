App.onJoinPlayer.Add(function(player) {
    App.showCenterLabel(`83타워 외부`);
})