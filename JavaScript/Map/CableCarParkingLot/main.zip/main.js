App.onJoinPlayer.Add(function(player) {
    App.showCenterLabel(`케이블카 주차장`);
})
